﻿// See https://aka.ms/new-console-template for more information
using FFMediaToolkit;
using FFMediaToolkit.Decoding;

// Point this to the folder containing the ffmpeg .dll files
// If using FFmpeg.Nightly.Shared, they are usually in the execution directory
FFmpegLoader.FFmpegPath = AppContext.BaseDirectory;
